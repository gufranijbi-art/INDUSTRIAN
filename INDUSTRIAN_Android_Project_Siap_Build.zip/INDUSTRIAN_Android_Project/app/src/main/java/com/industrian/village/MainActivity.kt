package com.industrian.village

import android.app.Activity
import android.os.Bundle
import android.opengl.GLSurfaceView
import android.view.*
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.pm.ActivityInfo
import android.opengl.GLES20
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var game: VillageView
    private lateinit var renderer: VillageRenderer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        renderer = VillageRenderer()
        game = VillageView(this, renderer)
        val root = FrameLayout(this)
        root.addView(game)
        val title = TextView(this).apply {
            text = "INDUSTRIAN  •  DESA 3D"
            setTextColor(Color.WHITE); textSize = 17f
            setPadding(22, 14, 22, 14)
            background = bg(0xAA174C38.toInt(), 18)
        }
        root.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        val joy = Joystick(this) { x, y -> renderer.moveX = x; renderer.moveY = y }
        val jp = FrameLayout.LayoutParams(150, 150, Gravity.BOTTOM or Gravity.START).apply { leftMargin=24; bottomMargin=22 }
        root.addView(joy, jp)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(8,8,8,8) }
        val jump = Button(this).apply { text="LOMPAT"; setOnClickListener { renderer.jump = true }; background = bg(0xDD205D43.toInt(), 48); setTextColor(Color.WHITE) }
        val camera = Button(this).apply { text="KAMERA"; setOnClickListener { renderer.cameraSide = !renderer.cameraSide }; background = bg(0xDD205D43.toInt(), 48); setTextColor(Color.WHITE) }
        actions.addView(jump, LinearLayout.LayoutParams(112,58).apply { bottomMargin=10 })
        actions.addView(camera, LinearLayout.LayoutParams(112,58))
        root.addView(actions, FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM or Gravity.END).apply { rightMargin=22; bottomMargin=22 })
        val info = TextView(this).apply { text="Joystick: bergerak     Tombol LOMPAT: melompat"; setTextColor(Color.WHITE); textSize=12f; setPadding(12,7,12,7); background=bg(0x88333333.toInt(),14) }
        root.addView(info, FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin=10 })
        setContentView(root)
    }
    private fun bg(color:Int, radius:Int)=GradientDrawable().apply { setColor(color); cornerRadius=radius.toFloat() }
    override fun onPause(){ super.onPause(); game.onPause() }
    override fun onResume(){ super.onResume(); game.onResume() }
}

class VillageView(ctx: android.content.Context, val renderer: VillageRenderer): GLSurfaceView(ctx) {
    init { setEGLContextClientVersion(2); setRenderer(renderer); renderMode=RENDERMODE_CONTINUOUSLY }
}
class Joystick(ctx: android.content.Context, val update:(Float,Float)->Unit): View(ctx) {
    private val p=android.graphics.Paint(3)
    private var dx=0f; private var dy=0f; private var active=false
    override fun onDraw(c:android.graphics.Canvas) {
        val r=width.coerceAtMost(height)*.46f; val cx=width/2f; val cy=height/2f
        p.color=0x77305D50; c.drawCircle(cx,cy,r,p)
        p.color=Color.WHITE; p.style=android.graphics.Paint.Style.STROKE; p.strokeWidth=4f; c.drawCircle(cx,cy,r,p); p.style=android.graphics.Paint.Style.FILL
        p.color=0xFFE4F2D9.toInt(); c.drawCircle(cx+dx,cy+dy,r*.36f,p)
    }
    override fun onTouchEvent(e:MotionEvent):Boolean {
        val r=width.coerceAtMost(height)*.46f; val max=r*.62f
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN,MotionEvent.ACTION_MOVE -> { active=true; val x=e.x-width/2f; val y=e.y-height/2f; val l=hypot(x,y); val k=if(l>max)max/l else 1f; dx=x*k; dy=y*k; update(dx/max,dy/max); invalidate(); return true }
            MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL -> { active=false; dx=0f;dy=0f;update(0f,0f);invalidate();return true }
        }; return true
    }
}

class VillageRenderer: GLSurfaceView.Renderer {
    @Volatile var moveX=0f; @Volatile var moveY=0f; @Volatile var jump=false; @Volatile var cameraSide=false
    private var program=0; private var cube=0; private var cubeCount=36
    private val projection=FloatArray(16); private val view=FloatArray(16); private val model=FloatArray(16); private val mv=FloatArray(16); private val mvp=FloatArray(16)
    private var px=0f; private var pz=18f; private var py=0f; private var vy=0f; private var walk=0f
    private var aPos=0; private var aNormal=0; private var uMvp=0; private var uModel=0; private var uColor=0
    private val vertexShader="""attribute vec3 aPosition; attribute vec3 aNormal; uniform mat4 uMVP; uniform mat4 uModel; uniform vec3 uColor; varying vec3 vColor; void main(){float d=max(dot(normalize(mat3(uModel)*aNormal),normalize(vec3(-0.4,0.9,0.3))),0.0);vColor=uColor*(0.48+0.52*d);gl_Position=uMVP*vec4(aPosition,1.0);}"""
    private val fragmentShader="""precision mediump float; varying vec3 vColor; void main(){gl_FragColor=vec4(vColor,1.0);}"""
    override fun onSurfaceCreated(gl:GL10?, config:EGLConfig?) {
        GLES20.glClearColor(.53f,.78f,.89f,1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        program=GLES20.glCreateProgram()
        val vs=compile(GLES20.GL_VERTEX_SHADER,vertexShader); val fs=compile(GLES20.GL_FRAGMENT_SHADER,fragmentShader)
        GLES20.glAttachShader(program,vs); GLES20.glAttachShader(program,fs); GLES20.glLinkProgram(program); GLES20.glUseProgram(program)
        aPos=GLES20.glGetAttribLocation(program,"aPosition"); aNormal=GLES20.glGetAttribLocation(program,"aNormal")
        uMvp=GLES20.glGetUniformLocation(program,"uMVP");uModel=GLES20.glGetUniformLocation(program,"uModel");uColor=GLES20.glGetUniformLocation(program,"uColor")
        cube=createCube()
    }
    private fun compile(type:Int,src:String):Int { val s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s }
    private fun createCube():Int {
        val v=ArrayList<Float>()
        fun face(a:FloatArray,b:FloatArray,c:FloatArray,d:FloatArray,n:FloatArray){ for(p in listOf(a,b,c,a,c,d)) { v.addAll(p.toList());v.addAll(n.toList()) } }
        face(floatArrayOf(-.5f,-.5f,.5f),floatArrayOf(.5f,-.5f,.5f),floatArrayOf(.5f,.5f,.5f),floatArrayOf(-.5f,.5f,.5f),floatArrayOf(0f,0f,1f))
        face(floatArrayOf(.5f,-.5f,-.5f),floatArrayOf(-.5f,-.5f,-.5f),floatArrayOf(-.5f,.5f,-.5f),floatArrayOf(.5f,.5f,-.5f),floatArrayOf(0f,0f,-1f))
        face(floatArrayOf(-.5f,-.5f,-.5f),floatArrayOf(-.5f,-.5f,.5f),floatArrayOf(-.5f,.5f,.5f),floatArrayOf(-.5f,.5f,-.5f),floatArrayOf(-1f,0f,0f))
        face(floatArrayOf(.5f,-.5f,.5f),floatArrayOf(.5f,-.5f,-.5f),floatArrayOf(.5f,.5f,-.5f),floatArrayOf(.5f,.5f,.5f),floatArrayOf(1f,0f,0f))
        face(floatArrayOf(-.5f,.5f,.5f),floatArrayOf(.5f,.5f,.5f),floatArrayOf(.5f,.5f,-.5f),floatArrayOf(-.5f,.5f,-.5f),floatArrayOf(0f,1f,0f))
        face(floatArrayOf(-.5f,-.5f,-.5f),floatArrayOf(.5f,-.5f,-.5f),floatArrayOf(.5f,-.5f,.5f),floatArrayOf(-.5f,-.5f,.5f),floatArrayOf(0f,-1f,0f))
        val data=ByteBuffer.allocateDirect(v.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer();v.forEach{data.put(it)};data.position(0)
        val ids=IntArray(1);GLES20.glGenBuffers(1,ids,0);GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER,ids[0]);GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER,v.size*4,data,GLES20.GL_STATIC_DRAW);return ids[0]
    }
    override fun onSurfaceChanged(gl:GL10?,w:Int,h:Int){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(projection,0,62f,w.toFloat()/h,0.1f,220f)}
    private fun draw(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,r:Float,g:Float,b:Float) {
        Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);Matrix.scaleM(model,0,sx,sy,sz)
        Matrix.multiplyMM(mv,0,view,0,model,0);Matrix.multiplyMM(mvp,0,projection,0,mv,0)
        GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES20.glUniformMatrix4fv(uModel,1,false,model,0);GLES20.glUniform3f(uColor,r,g,b)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER,cube);GLES20.glEnableVertexAttribArray(aPos);GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,24,0);GLES20.glEnableVertexAttribArray(aNormal);GLES20.glVertexAttribPointer(aNormal,3,GLES20.GL_FLOAT,false,24,12);GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,cubeCount)
    }
    private fun house(x:Float,z:Float,variant:Boolean) {
        val wall=if(variant) floatArrayOf(.88f,.82f,.67f) else floatArrayOf(.85f,.68f,.43f)
        draw(x,1.2f,z,4.8f,2.4f,4f,wall[0],wall[1],wall[2])
        // pitched roof represented by two sloping roof panels
        draw(x-.9f,2.65f,z,2.55f,.22f,4.7f,.48f,.22f,.14f)
        draw(x+.9f,2.65f,z,2.55f,.22f,4.7f,.48f,.22f,.14f)
        draw(x,1f,z+2.06f,.85f,2f,.12f,.25f,.14f,.08f)
        for(wx in listOf(-1.35f,1.35f)){draw(x+wx,1.55f,z+2.08f,.8f,.68f,.1f,.28f,.64f,.69f)}
        draw(x,.16f,z+2.8f,1.6f,.25f,1.4f,.35f,.23f,.12f)
    }
    private fun tree(x:Float,z:Float,k:Float) {
        draw(x,.9f*k,z,.42f*k,1.8f*k,.42f*k,.34f,.20f,.09f)
        draw(x,2.2f*k,z,1.8f*k,1.9f*k,1.8f*k,.13f,.39f,.15f)
        draw(x-.5f*k,2.35f*k,z+.12f,.95f*k,1.05f*k,.95f*k,.22f,.49f,.18f)
    }
    private fun person() {
        draw(px,1.68f+py,pz,.68f,.76f,.68f,.73f,.49f,.32f)
        draw(px,1.92f+py,pz,.72f,.34f,.72f,.12f,.08f,.05f)
        draw(px,1.05f+py,pz,.85f,1f,.48f,.13f,.39f,.62f)
        val sw=sin(walk)*.22f
        draw(px-.23f,.42f+py,pz+sw,.25f,.82f,.28f,.13f,.18f,.25f)
        draw(px+.23f,.42f+py,pz-sw,.25f,.82f,.28f,.13f,.18f,.25f)
        draw(px-.49f,1.04f+py,pz,.19f,.78f,.2f,.73f,.49f,.32f)
        draw(px+.49f,1.04f+py,pz,.19f,.78f,.2f,.73f,.49f,.32f)
    }
    override fun onDrawFrame(gl:GL10?) {
        val dt=.016f
        val f=-moveY; val s=moveX; val len=hypot(f,s)
        if(len>.08f){px+=(s/ max(1f,len))*dt*6f;pz-=(f/max(1f,len))*dt*6f;walk+=dt*11f}
        px=px.coerceIn(-25f,25f);pz=pz.coerceIn(-75f,75f)
        if(jump && py<=0.001f){vy=7f};jump=false
        vy-=18f*dt;py+=vy*dt;if(py<0){py=0f;vy=0f}
        val eyeX=if(cameraSide)px+9f else px
        val eyeZ=if(cameraSide)pz+9f else pz+10f
        Matrix.setLookAtM(view,0,eyeX,6.5f,eyeZ,px,1.1f,pz-3f,0f,1f,0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        draw(0f,-.25f,0f,180f,.5f,180f,.34f,.57f,.24f)
        draw(0f,-.02f,0f,7f,.08f,180f,.56f,.47f,.35f)
        for(x in listOf(-18f,18f)){draw(x,-.12f,0f,18f,.12f,180f,.43f,.67f,.31f);draw(x,-.02f,0f,1f,.12f,180f,.22f,.55f,.61f)}
        for(z in -75..75 step 18){house(-10f,z.toFloat(),z%2==0);house(10f,z+8f,z%2!=0)}
        for(z in -85..85 step 8){tree(-6.5f,z.toFloat(),.85f);tree(6.5f,z+3f,.9f)}
        for(i in -8..8){draw(i*12f,1f,-92f,12f,8f,12f,.39f,.59f,.32f)}
        person()
    }
}
